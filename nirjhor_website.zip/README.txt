# Nirjhor™ Website

A funny, self-contained website made with plain HTML, CSS, and JavaScript.

## Open it
Double-click `index.html` and it should open in Chrome.

## Put it online
Upload `index.html` to a static hosting service such as GitHub Pages or Netlify.
